
// Mock emulator for Nvs Audio Dsp Emulator

class NvsAudioDspEmulator {
  void connect() {
    print("Connecting to nvs audio dsp emulator...");
  }

  void testSignal() {
    print("Running test signal...");
  }

  void simulateResponse() {
    print("DSP response simulated successfully.");
  }
}
